#include "stdafx.h"
#include "Bp_Var_house.h"

Bp_Var_house::Bp_Var_house()
	: Bias(1)
	, Weight_Layer(NULL)
	, Weight_Input_Layer(NULL)
	, Weight_Output_Layer(NULL)
	, Input(NULL)
	, Target_t(NULL)
	, Sigmoid(NULL)
	, Delta(NULL)
	, Sum_Output(NULL)
	, Sigmoid_Output(NULL)
	, Delta_Output(NULL)
	, Number_Neurons(0)
	, Number_Layer(0)
	, nInput_Number_Inputs(0)
	, nInput_Number_Hidden_Layer(0)
	, nInput_Number_Hidden_Neurons(0)
	, nInput_Number_Outputs(0)
	, Hidden_Layer(NULL)
	, Bias_Weight(NULL)
	, In_Out_Number(0)
	, Flag_In_Out(0)
	, Input_Array(0)
	, Output_Iteration(0)
	, Count_Output(0)
	, Output_Array(0)
	, Input_Choice(0)
	, Get_Read_text_Length(0)
	, L_N_G(0)
	, epoch_limit(0)
	, Sum(NULL)
	, Error(NULL)
	, Error_Result(NULL)
	, Error_add(NULL)
	
{
	StartTime = 0, EndTime = 0;

	
}


Bp_Var_house::~Bp_Var_house()
{
	cout << "�Ҹ� Bp_Var" << endl;
	delete[] Input;
	delete[] Target_t;
	delete[] Bias_Weight;
	delete[] Weight_Layer;
	delete[] Weight_Input_Layer;
	delete[] Weight_Output_Layer;
	delete[] Sigmoid;
	delete[] Delta;
	delete[] Sum_Output;
	delete[] Sigmoid_Output;
	delete[] Delta_Output;

}


// ��ü ���� + Weight �� ��� ���� ����
void Bp_Var_house::All_Neurons()
{
	
	
		cout << "Input : ";
		scanf_s("%d", &nInput_Number_Inputs);
		
		cout << "Output : ";
		scanf_s("%d", &nInput_Number_Outputs);

		if (nInput_Number_Inputs == 0 || nInput_Number_Outputs == 0)
		{
			cout << "Input , Output �� 0 �� �ƴ� �� �̿��� �մϴ�." << endl;
			Bp_Var_house::All_Neurons();
		}
		if ((nInput_Number_Inputs + nInput_Number_Outputs) != (Get_text_Array + 1))
		{
			cout << "Data ��� ���� �ʰ�! Input+Output �� Data ����"<<"("<< Get_text_Array + 1<<")"<<"�� ���Ͽ� ���ų� ������ �ȵ˴ϴ�." << endl;
			All_Neurons();
		}
		cout << "Learning gain :";
		scanf_s("%lf", &L_N_G);
		if (L_N_G > 1 || L_N_G < 0)
		{
			cout << "Learning gain ���� �ʰ�! 0.4�� �����մϴ�." << endl;
			L_N_G = 0.4;
		}
		cout << "Input Hidden Layer(����1~5) :";
		scanf_s("%d", &nInput_Number_Hidden_Layer);

	/*	nInput_Number_Inputs = 2;
		nInput_Number_Outputs = 1;
		L_N_G = 0.4;
		nInput_Number_Hidden_Layer = 2;*/
		
		if (nInput_Number_Hidden_Layer <= 0)
		{
			cout << "���� �ʰ�! 5�� �ڵ� ����" << endl;
			nInput_Number_Hidden_Layer = 5;
		}

		Number_Layer = nInput_Number_Hidden_Layer;

		Hidden_Layer = new int[Number_Layer]();

		for (int i = 0; i < Number_Layer; ++i)
		{
			cout << "Input Neurons in Hidden Layer-" << i + 1 << "��" << "  (Max:10) :";
			scanf_s("%d", &Hidden_Layer[i]);
			if (Hidden_Layer[i] <= 0)
			{
				cout << "�Է� ���� ����! Neurons 10���� �ڵ� �����մϴ�." << endl;
				Hidden_Layer[i] = 10;
			}
			//Hidden_Layer[i] = 50;
			Number_Neurons += Hidden_Layer[i];		//�� Neurons ���� ����
		}
		Number_Neurons += nInput_Number_Outputs;

		cout << "Epoch limit :";
		scanf_s("%d", &epoch_limit);
		//epoch_limit = 5000;
		
		Bp_Var_house::fAssignment_HLayer();			//Neurons ���� �Ҵ�
}


void Bp_Var_house::fAssignment_HLayer()				//Neurons ���� �Ҵ�
{
	//StartTime = clock();

	Input = new double[Get_text_Line * nInput_Number_Inputs]();			// Input , Output���Ƿ� �صα� �ߴµ� ���� �ٲ����
	Target_t = new double*[Get_text_Line]();
	for (int i = 0; i < Get_text_Line; ++i)
	{
		Target_t[i] = new double[nInput_Number_Outputs]();									//ex) Output 2 --> [0][0~Ite] [1][0~Ite]	
	}

	/*	Weight �޸� �Ҵ�	*/
	Bias_Weight = new double[Number_Neurons]();

	Weight_Layer = new double*[Number_Layer - 1]();

	for (int i = 0; i < (Number_Layer - 1); ++i)
	{
		Weight_Layer[i] = new double[Hidden_Layer[i] * Hidden_Layer[i + 1]]();
	}

	Weight_Input_Layer = new double[nInput_Number_Inputs * Hidden_Layer[0]]();

	Weight_Output_Layer = new double[nInput_Number_Outputs*Hidden_Layer[Number_Layer - 1]]();

	/*	Sum, Sigmoid, Delta �޸� �Ҵ�*/
	//�� ���� ���� ����� �����ؾ���. 1�� ��� 2�� �̻���

	Sigmoid = new double[Number_Neurons - nInput_Number_Outputs]();
	Sum = new double[Number_Neurons - nInput_Number_Outputs]();
	Delta = new double[Number_Neurons - nInput_Number_Outputs]();

	/*	Sum, Sigmoid, Delta �޸� �Ҵ�(Out Layer)*/
	Sigmoid_Output = new double[nInput_Number_Outputs]();
	Sum_Output = new double[nInput_Number_Outputs]();
	Delta_Output = new double[nInput_Number_Outputs]();
	Error = new double[nInput_Number_Outputs]();
	Error_Result = new double[nInput_Number_Outputs]();
	Error_add = new double[nInput_Number_Outputs]();


	//Bp_Var_house::fReadFile();		// .txt���� ��ǲ Ÿ�� �� ����
	//Bp_Var_house::fRandom_Weight();	// Random Weight ����
}


void Bp_Var_house::fReadFile()		// .txt���� ��ǲ Ÿ�� �� ����
{
	In_Out_Number = (nInput_Number_Inputs + nInput_Number_Outputs);
	ifstream inFile_Read_Data;

	inFile_Read_Data.open(psz_textData);
	if (inFile_Read_Data.is_open() == false)		cout << "Data ���� �о���� ����!" << endl;
	for (int i = 0; i < (In_Out_Number * Get_text_Line); ++i)
	{
		Flag_In_Out = (i % In_Out_Number);
		if (Flag_In_Out < nInput_Number_Inputs)
		{
			inFile_Read_Data >> Input[Input_Array];
			++Input_Array;
		}
		else
		{

			++Count_Output; // 1 2 3 4 
			inFile_Read_Data >> Target_t[Output_Iteration][Output_Array % nInput_Number_Outputs];
			if (Count_Output % nInput_Number_Outputs == 0) ++Output_Iteration;

			++Output_Array;
		}
	}
}


void Bp_Var_house::fRandom_Weight()
{
	srand((unsigned)time(NULL));
	for (int i = 0; i < Number_Neurons; ++i)			//Bias Weight Random
	{
		Bias_Weight[i] = ((rand() % 20000) * 0.0001) - 1.0000;
	}

	for (int i = 0; i < (nInput_Number_Inputs *Hidden_Layer[0]); ++i)
	{
		Weight_Input_Layer[i] = ((rand() % 20000) * 0.0001) - 1.0000;
	}

	for (int i = 0; i < (Number_Layer - 1); ++i)
	{
		for (int j = 0; j < (Hidden_Layer[i] * Hidden_Layer[i + 1]); ++j)
		{
			Weight_Layer[i][j] = ((rand() % 20000) * 0.0001) - 1.0000;
		}
	}

	for (int i = 0; i < (nInput_Number_Outputs*Hidden_Layer[Number_Layer - 1]); ++i)
	{
		Weight_Output_Layer[i] = ((rand() % 20000) * 0.0001) - 1.0000;
	}



	//EndTime = clock();
	//gap = (double)(EndTime - StartTime) / CLOCKS_PER_SEC;
	//cout << gap << "�� ���(���� ���� + ���� �Ҵ� Time)" << endl;

}


void Bp_Var_house::Print_()
{
	cout << "********************************************" << endl;
	cout << "***************���� �Է� Ȯ��****************" << endl;
	cout << "********************************************" << endl;

	cout << "Input :" << nInput_Number_Inputs << endl;				//�Է� ����
	cout << "Output :" << nInput_Number_Outputs << endl;				//�ƿ� ����
	cout << "Learning gain :" << L_N_G << endl;				//Learning gain
	cout << "Number of Hidden Layer :" << Number_Layer << endl;				//Hidden Layer
	for (int i = 0; i < Number_Layer; ++i)
	{
		cout << "Hidden Layer-" << i + 1 << " Neurons :" << Hidden_Layer[i] << endl;				//Layer�� Neurons
	}
	cout << "All Neuorns : " << Number_Neurons + nInput_Number_Inputs << endl;
	cout << "Epoch limit : " << epoch_limit << endl << endl;

	cout << "���� [1]	�Է� �� ���� [2]			�Է� : ";
	cin >> Input_Choice;
	if (Input_Choice == 2)
	{
		cout << "�Է� ���� �����մϴ�." << endl;
		Bp_Var_house::All_Neurons();
	}



	Bp_Var_house::fReadFile();		// .txt���� ��ǲ Ÿ�� �� ����
	Bp_Var_house::fRandom_Weight();	// Random Weight ����

}


void Bp_Var_house::TestBP_V()
{
}


void Bp_Var_house::fBP_Learn()
{
}
