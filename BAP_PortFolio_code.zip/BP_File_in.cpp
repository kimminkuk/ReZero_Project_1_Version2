#include "stdafx.h"
#include "BP_File_in.h"


BP_File_in::BP_File_in()
	: psz_textData(NULL)
	, count(0)
	, Get_Read_text_Length(0)
	, Get_text_Array(0)
	, Get_text_Line(0)
	, gap(0)
	, StartTime(0)
	, EndTime(0)
{
	//StartTime = clock();
}


BP_File_in::~BP_File_in()
{
	cout << "�Ҹ� BP_FIle_in" << endl;
}


void BP_File_in::fSelect_txt(const int pszParam)
{
	
	StartTime = clock();
	switch (pszParam)
	{
	case COUNT_1:
	{
		psz_textData = new char[strlen("train_iris_1.txt") + 1]();
		strcpy_s(psz_textData, sizeof(char)*(strlen("train_iris_1.txt") + 1), "train_iris_1.txt");
		break;
	}

	case COUNT_2:
	{
		psz_textData = new char[strlen("train_iris_2.txt") + 1]();
		strcpy_s(psz_textData, sizeof(char)*(strlen("train_iris_2.txt") + 1), "train_iris_2.txt");
		break;
	}
	case COUNT_3:
	{
		psz_textData = new char[strlen("EX_OR.txt") + 1]();
		strcpy_s(psz_textData, sizeof(char)*(strlen("EX_OR.txt") + 1), "EX_OR.txt");
		break;
	}
	case COUNT_4:
	{

		psz_textData = new char[strlen("Test_07_06.txt") + 1]();
		strcpy_s(psz_textData, sizeof(char)*(strlen("Test_07_06.txt") + 1), "Test_07_06.txt");
		break;
	}
	case COUNT_5:
	{
		cout << "�а��� �ϴ� Text :";
		char Get_Text_Direct_Input[1024] = { 0 };
		cin >> Get_Text_Direct_Input;
		psz_textData = new char[strlen(Get_Text_Direct_Input) + 1]();
		strcpy_s(psz_textData, sizeof(char) * (strlen(Get_Text_Direct_Input) + 1), Get_Text_Direct_Input);
		break;
	}
	default:
	{
		int temp(0);
		cout << "���� 1~5 ���� �ٽ� �Է� ��� : ";
		cin >> temp;
		fSelect_txt(temp);
		break;
	}
	}

	fGet_File_Array(psz_textData);
}


void BP_File_in::fGet_File_Array(const char* pszFile)
{
	putchar('\n');
	FILE *Line_Check;
	fopen_s(&Line_Check, pszFile, "r");

	while (fgets(Get_text_fgets, sizeof(Get_text_fgets), Line_Check) != NULL)
	{
		cout << Get_text_fgets;
		++count;
	}
	Get_Read_text_Length = strlen(Get_text_fgets);
	for (int i = 0; i < Get_Read_text_Length; ++i)
	{
		if ((*(Get_text_fgets + i) == ' ') || (*(Get_text_fgets + i) == '\t'))
		{
			++Get_text_Array;
		}
	}
	fclose(Line_Check);
	Get_text_Line = count;
	putchar('\n');
	putchar('\n');
	cout << "�Է��� " << pszFile << " ������ : " << Get_text_Array + 1 << "x" << Get_text_Line << "  (������ ������ �ٸ� ��� ����)" << endl << endl;

	EndTime = clock();
	gap = (double)(EndTime - StartTime) / CLOCKS_PER_SEC;
	cout << gap << "�� ���(BPA Time)" << endl;

}
