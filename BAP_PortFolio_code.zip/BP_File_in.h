#pragma once

enum NUMBERTXT{COUNT_1 = 1, COUNT_2, COUNT_3, COUNT_4, COUNT_5};

class BP_File_in
{
public:
	BP_File_in();
	~BP_File_in();
protected:
	char *psz_textData;
public:
	void fSelect_txt(const int param);
private:
	void fGet_File_Array(const char* pszFile);
protected:
	char Get_text_fgets[4096];
	int count;
	int Get_Read_text_Length;
	int Get_text_Array;
	int Get_text_Line;
	time_t StartTime;
	time_t EndTime;
	double gap;
};

