#include "stdafx.h"
#include "BP_Test.h"


BP_Test::BP_Test()
	: Out_Jump(0)
	, inc(0)
	, k(0)
	, l(0)
	, bnc(0)
	, Bias(1)
	, Get_text_Input(0)
	, Get_text_Output(0)
	, Get_text_Layer(0)
	, T_Hidden_Layer(NULL)
	, Weight_L(NULL)
	, Weight_Input_L(NULL)
	, Weight_Output_L(NULL)
	, Weight_Bias_L(NULL)
	, Get_text_Neurons(0)
	, T_Input(NULL)
	, T_Output(NULL)
	, T_LNG(0)
	, T_Sum(NULL)
	, T_Sigmoid(NULL)
	, T_Output_Sum(NULL)
	, T_Output_Sigmoid(NULL)
{
}


BP_Test::~BP_Test()
{
	delete[] T_Hidden_Layer;
	delete[] Weight_L;
	delete[] Weight_Input_L;
	delete[] Weight_Output_L;
	delete[] Weight_Bias_L;
	delete[] T_Input;
	delete[] T_Output;
	delete[] T_Sum;
	delete[] T_Sigmoid;
	delete[] T_Output_Sum;
	delete[] T_Output_Sigmoid;
}


void BP_Test::Test()
{
	ifstream Read_Input_Number, Read_Target_Number, Read_Layer_Number, Read_Hidden_Neurons_Number, Read_Neurons_Number, Read_LNG;
	ifstream Read_W_L_Input, Read_W_L_Output, Read_W_L_Bias;

	Read_LNG.open("Learning_Gain.txt");
	Read_Input_Number.open("Number_Input.txt");
	Read_Target_Number.open("Number_Output.txt");
	Read_Layer_Number.open("Number_Layer.txt");
	Read_Neurons_Number.open("Number_Neurons.txt");
	Read_Hidden_Neurons_Number.open("Number_Hidden_Neurons.txt");
	Read_W_L_Input.open("Weight_Input.txt");
	Read_W_L_Output.open("Weight_Output.txt");
	Read_W_L_Bias.open("Weight_Bias.txt");

	//Learning Gain
	if (Read_LNG.is_open() == false)					cout << "text ����(Learning gain) x" << endl;
	Read_LNG >> T_LNG;

	//Input
	if (Read_Input_Number.is_open() == false)		cout << "text ����(Input) x" << endl;
	Read_Input_Number >> Get_text_Input;
	T_Input = new double[Get_text_Input]();
	//Output
	if (Read_Target_Number.is_open() == false)		cout << "text ����(Output) x" << endl;
	Read_Target_Number >> Get_text_Output;
	T_Output = new double[Get_text_Output]();
	//Layer
	if (Read_Layer_Number.is_open() == false)		cout << "text ����(Layer) x" << endl;
	Read_Layer_Number >> Get_text_Layer;
	//Neurons
	if (Read_Neurons_Number.is_open() == false)		cout << "text ����(Neurons) x" << endl;
	Read_Neurons_Number >> Get_text_Neurons;

	T_Hidden_Layer = new int[Get_text_Layer]();
	Weight_L = new double*[Get_text_Layer - 1]();
	T_Sum = new double[Get_text_Neurons - Get_text_Output]();
	T_Sigmoid = new double[Get_text_Neurons - Get_text_Output]();
	T_Output_Sum = new double[Get_text_Output]();
	T_Output_Sigmoid = new double[Get_text_Output]();

	// Hidden Layer Neurons
	if (Read_Hidden_Neurons_Number.is_open() == false)	cout << "text ����(Hidden Layer Neurons) x" << endl;
	for (int i = 0; i < Get_text_Layer; ++i)
	{
		Read_Hidden_Neurons_Number >> T_Hidden_Layer[i];
	}

	//Layer ���� Weight
	for (int i = 0; i < (Get_text_Layer - 1); ++i)
	{
		Weight_L[i] = new double[T_Hidden_Layer[i] * T_Hidden_Layer[i + 1]]();
	}
	char filename[100] = { 0 };
	for (int i = 0; i < (Get_text_Layer - 1); ++i)
	{
		sprintf_s(filename, "Weight_Layer_%d.txt", i + 1);
		ifstream W_Read_Layer;
		W_Read_Layer.open(filename);
		for (int j = 0; j < (T_Hidden_Layer[i] * T_Hidden_Layer[i + 1]); ++j)
		{
			W_Read_Layer >> Weight_L[i][j];
		}
	}




	//Weight Input <---> Hidden Layer
	if (Read_W_L_Input.is_open() == false)			cout << "text ����(Weight_Input) x" << endl;
	Weight_Input_L = new double[Get_text_Input * T_Hidden_Layer[0]]();
	for (int i = 0; i < (Get_text_Input * T_Hidden_Layer[0]); ++i)
	{
		Read_W_L_Input >> Weight_Input_L[i];
	}
	//Weight Hidden Layer <---> Output
	if (Read_W_L_Output.is_open() == false)			cout << "text ����(Weight_Output) x" << endl;
	Weight_Output_L = new double[Get_text_Output * T_Hidden_Layer[Get_text_Layer - 1]]();
	for (int i = 0; i < (Get_text_Output * T_Hidden_Layer[Get_text_Layer - 1]); ++i)
	{
		Read_W_L_Output >> Weight_Output_L[i];
	}
	//Weight Bias
	if (Read_W_L_Bias.is_open() == false)			cout << "text ����(Weight_Bias) x" << endl;
	Weight_Bias_L = new double[Get_text_Neurons]();
	for (int i = 0; i < Get_text_Neurons; ++i)
	{
		Read_W_L_Bias >> Weight_Bias_L[i];
	}


	if (Read_Hidden_Neurons_Number.is_open() == true)		Read_Hidden_Neurons_Number.close();
	if (Read_Neurons_Number.is_open() == true)		Read_Neurons_Number.close();
	if (Read_Input_Number.is_open() == true)		Read_Input_Number.close();
	if (Read_Target_Number.is_open() == true)		Read_Target_Number.close();
	if (Read_Layer_Number.is_open() == true)		Read_Layer_Number.close();
	if (Read_W_L_Input.is_open() == true)	Read_W_L_Input.close();
	if (Read_W_L_Output.is_open() == true)	Read_W_L_Output.close();
	if (Read_W_L_Bias.is_open() == true)	Read_W_L_Bias.close();
	if (Read_LNG.is_open() == true)			Read_LNG.close();



	inc = 0;
	int carry(0);
	// Output�� ����� Neurons Min Number
	int Lable(Get_text_Neurons - T_Hidden_Layer[Get_text_Layer - 1] - Get_text_Output);
	// Output�� ����� Neurons Max Number
	int New_Lable(Get_text_Neurons - Get_text_Output);

	/*Test�� Input �� �Է�*/
	for (int i = 0; i < Get_text_Input; ++i)
	{
		cout << i + 1 << "��°" << " Test Input : ";
		cin >> T_Input[i];
	}

	/*Input - Hidden Layer[0] ���� Sum,Sigmoid,Delta */
	for (int i = 0; i < T_Hidden_Layer[0]; ++i)
	{
		for (int j = 0; j < Get_text_Input; ++j)
		{
			T_Sum[i] += (T_Input[j + bnc * 2] * Weight_Input_L[inc]);
			++inc;
		}
		T_Sum[i] += (Bias * Weight_Bias_L[i]);
		T_Sigmoid[i] = (1.0 / (1.0 + exp(-T_Sum[i])));
	}
	inc = 0;

	/*Hidden Layer�� ������ Sum, Sigmoid*/
	for (int i = 0; i < (Get_text_Layer - 1); ++i)
	{
		l += T_Hidden_Layer[i];
		for (int j = l; j < (l + T_Hidden_Layer[i + 1]); ++j)
		{
			for (int k = Out_Jump; k < l; ++k)
			{
				T_Sum[j] += (T_Sigmoid[k] * Weight_L[i][inc]);
				++inc;
			}
			T_Sum[j] += (Bias * Weight_Bias_L[j]);
			T_Sigmoid[j] = (1.0 / (1.0 + exp(-T_Sum[j])));
		}
		inc = 0;
		Out_Jump += T_Hidden_Layer[i];
	}
	Out_Jump = 0;
	l = 0;
	/*	Output Layer�� ����� Hidden Layer�̿��Ͽ� Output Sum,Sigmoid	*/
	for (int i = 0; i < Get_text_Output; ++i)
	{
		for (int j = Lable; j < New_Lable; ++j)
		{
			T_Output_Sum[i] += (T_Sigmoid[j] * Weight_Output_L[inc]);
			++inc;
		}
		T_Output_Sum[i] += (Bias * Weight_Bias_L[New_Lable + i]);
		T_Output_Sigmoid[i] = (1.0 / (1.0 + exp(-T_Output_Sum[i])));
	}
	inc = 0;

	//Test ���
	for (int i = 0; i < Get_text_Output; ++i)
	{
		cout << "Test : " << fabs(T_Output_Sigmoid[i]) << endl;
	}
}
