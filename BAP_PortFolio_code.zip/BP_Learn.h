#pragma once
#include "Bp_Var_house.h"
class BP_Learn :
	public Bp_Var_house
{
public:
	BP_Learn();
	~BP_Learn();
	void fBP_Learn();		//Learn

	void TestBP_V();		//Test(���� �Լ�)
protected:
	int Flag;
	int inc;
	int bnc;
	int Out_Jump;
	int k;
	int l;
	int Iteration;
	int Epoch;
	double RMSE;
private:
	void fWrite_Weight();

};

