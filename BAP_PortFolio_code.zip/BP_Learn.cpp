#include "stdafx.h"
#include "BP_Learn.h"


BP_Learn::BP_Learn()
	: Flag(0)
	, inc(0)
	, bnc(0)
	, Out_Jump(0)
	, k(0)
	, l(0)
	, Iteration(0)
	, Epoch(0)
	, RMSE(0)
{
	StartTime = 0, EndTime = 0;
	
}


BP_Learn::~BP_Learn()
{
	cout << "Bp_Learn �Ҹ�" << endl;
}


void BP_Learn::fBP_Learn()
{
	//BP_Learn::Print();
	//StartTime = clock();
	StartTime = clock();
	while (Flag != 3)
	{
		
		inc = 0;
		int carry(0);
		// Output�� ����� Neurons Min Number
		int Lable(Number_Neurons - Hidden_Layer[Number_Layer - 1] - nInput_Number_Outputs);
		// Output�� ����� Neurons Max Number
		int New_Lable(Number_Neurons - nInput_Number_Outputs);

		/*Input - Hidden Layer[0] ���� Sum,Sigmoid,Delta */
		for (int i = 0; i < Hidden_Layer[0]; ++i)
		{
			for (int j = 0; j < nInput_Number_Inputs; ++j)
			{
				Sum[i] += (Input[j + bnc * nInput_Number_Inputs] * Weight_Input_Layer[inc]);
				++inc;
			}
			Sum[i] += (Bias * Bias_Weight[i]);
			Sigmoid[i] = (1.0 / (1.0 + exp(-Sum[i])));
		}
		inc = 0;

		/*Hidden Layer�� ������ Sum, Sigmoid*/
		for (int i = (Number_Layer - 1); i > 0; --i)
		{
			k += Hidden_Layer[i];
			for (int j = New_Lable - (Hidden_Layer[i] + Out_Jump); j < (New_Lable - Out_Jump); ++j)
			{
				for (int n = (New_Lable - (Hidden_Layer[i - 1] + k)); n < (New_Lable - k); ++n)
				{
					Sum[j] += (Sigmoid[n] * Weight_Layer[i - 1][inc]);
					++inc;
				}
				Sum[j] += (Bias * Bias_Weight[j]);
				Sigmoid[j] = (1.0 / (1.0 + exp(-Sum[j])));
			}
			inc = 0;
			Out_Jump += Hidden_Layer[i];
		}
		Out_Jump = 0;
		k = 0;

		/*	Output Layer�� ����� Hidden Layer�̿��Ͽ� Output Sum,Sigmoid	*/
		for (int i = 0; i < nInput_Number_Outputs; ++i)
		{
			for (int j = Lable; j < New_Lable; ++j)
			{
				Sum_Output[i] += (Sigmoid[j] * Weight_Output_Layer[inc]);
				++inc;
			}
			Sum_Output[i] += (Bias * Bias_Weight[New_Lable + i]);
			Sigmoid_Output[i] = (1.0 / (1.0 + exp(-Sum_Output[i])));
			Delta_Output[i] = (Sigmoid_Output[i] * (1 - Sigmoid_Output[i])) * (Target_t[bnc][i] - Sigmoid_Output[i]);
			/*Target �� ���� ����*/
			for (int j = Lable; j < New_Lable; ++j)
			{
				Delta[j] += (Sigmoid[j] * (1 - Sigmoid[j])*Weight_Output_Layer[carry] * Delta_Output[i]);
				++carry;
			}
		}
		inc = 0;


		/*Hidden Layer�� ������ Delta*/
		for (int i = Number_Layer - 1; i > 0; --i)
		{
			l += Hidden_Layer[i];
			for (int z = New_Lable - (Hidden_Layer[i] + Hidden_Layer[i - 1] + Out_Jump); z < (New_Lable - Hidden_Layer[i] - Out_Jump); ++z)
			{
				for (int j = (New_Lable - l); j < (New_Lable - Out_Jump); ++j)
				{
					Delta[z] += (Sigmoid[z] * (1 - Sigmoid[z])) * Delta[j] * Weight_Layer[i - 1][inc + k];
					k += Hidden_Layer[i - 1];
				}
				k = 0;
				++inc;
			}
			Out_Jump += Hidden_Layer[i];
			inc = 0;
		}
		l = 0;
		k = 0;
		inc = 0;
		Out_Jump = 0;


		/*Weight ����*/
		//Bias �κ�
		for (int i = 0; i < New_Lable; ++i)					Bias_Weight[i] = (L_N_G * Delta[i] * Bias) + Bias_Weight[i];
		for (int i = New_Lable; i < Number_Neurons; ++i)	Bias_Weight[i] = (L_N_G * Delta_Output[i - New_Lable] * Bias) + Bias_Weight[i];

		//Input <---> Hidden Layer 1�� �κ�
		for (int i = 0; i < (nInput_Number_Inputs * Hidden_Layer[0]); ++i)
		{
			l = i % nInput_Number_Inputs; //Input 2�� �϶� (l--> 0 1 0 1)
			if (i > 0)
			{							  //i--> 0 1 2 3 4 5 6 7  => l --> 0 1 0 1 0 1 0 1
				if (l == 0)			++k;  //K--> 0 0 1 1 2 2 3 3
			}
			Weight_Input_Layer[i] = (L_N_G * Delta[k] * Input[l + bnc * nInput_Number_Inputs]) + Weight_Input_Layer[i];
		}
		l = 0, k = 0;


		/*Hidden Layer ������ Weight ����*/
		for (int i = (Number_Layer - 1); i > 0; --i)
		{
			l += Hidden_Layer[i];
			for (int j = (New_Lable - l - Hidden_Layer[i - 1]); j < (New_Lable - l); ++j)
			{
				for (int k = (New_Lable - l); k < (New_Lable - Out_Jump); ++k)
				{
					Weight_Layer[i - 1][inc] = (L_N_G * Delta[k] * Sigmoid[j]) + Weight_Layer[i - 1][inc];
					++inc;
				}
			}
			Out_Jump += Hidden_Layer[i];
			inc = 0;
		}
		inc = 0;
		Out_Jump = 0;
		l = 0;

		//Hidden Layer(������ ��) <---> Output Layer
		for (int i = 0; i < (nInput_Number_Outputs *Hidden_Layer[Number_Layer - 1]); ++i)
		{
			l = i % Hidden_Layer[Number_Layer - 1];  // 0 1 2 3  0 1 2 3

			if (i > 0 && ((i % Hidden_Layer[Number_Layer - 1]) == 0))	 ++k;
			Weight_Output_Layer[i] = (L_N_G * Delta_Output[k] * Sigmoid[l + Lable]) + Weight_Output_Layer[i];
		}
		l = 0;
		k = 0;
		Out_Jump = 0;

		/*Delta += ����Ͽ��� ������ �ʱ�ȭ ���־�� ��*/
		for (int i = 0; i < New_Lable; ++i)				Delta[i] = 0;
		for (int i = 0; i < nInput_Number_Outputs; ++i)	Delta_Output[i] = 0;

		/*Sum += ���� �ʱ�ȭ*/
		for (int i = 0; i < New_Lable; ++i)				Sum[i] = 0;
		for (int i = 0; i < nInput_Number_Outputs; ++i) Sum_Output[i] = 0;

		/*���� Error �� ���ϴ� ��*/
		//Mean Square Error �����غ���
		//RMSE =  Root *( (1.0 / n) * Sigma(i) * pow((Target_Vector(i) - Output(i)) , 2)  )
		//��Ʈ --> sqrt(�Ǽ�)     ,    ���� --> pow(a , 2)
		for (int i = 0; i < nInput_Number_Outputs; ++i)
		{
			Error[i] = (Target_t[bnc][i] - Sigmoid_Output[i]);
			RMSE += ((1.0 / nInput_Number_Outputs) * pow(Error[i], 2));
			Error_add[i] += fabs(Error[i]);
		}
		RMSE = sqrt(RMSE);

		++bnc;
		++Iteration;
		if (bnc == Get_text_Line)		bnc = 0;		//�� �κ��� ���� �ؽ�Ʈ ���̿� ���� ���� ���־�� ��

														//ofstream Er;
														/*Error ���*/
		if ((Iteration % Get_text_Line) == 0)
		{
			++Epoch;
			//cout <<"Epoch :" <<Epoch <<"    RMSE :" <<RMSE<<endl;
			RMSE = 0;
			for (int i = 0; i < nInput_Number_Outputs; ++i)
			{
				//Er.open("Error.txt",ios_base::app);
				Error_Result[i] = (Error_add[i] / Get_text_Line);
				//Er << this->Error_Result[i] << endl;

				Error_add[i] = 0;
				//cout << i + 1 << "��° Error : " << Error_Result[i] << endl;
			}
			if (Epoch % 1000 == 0)
			{
				cout << "Epoch :" << Epoch << "    RMSE :" << RMSE << endl;
				for (int i = 0; i < nInput_Number_Outputs; ++i)
				{
					cout << i + 1 << "��° Error : " << Error_Result[i] << endl;
				}
			}
		}
		//Er.close();
		if (Epoch > epoch_limit)	Flag = 3;

	}	//While 


	EndTime = clock();
	gap = (double)(EndTime - StartTime) / CLOCKS_PER_SEC;
	cout << gap <<"�� ���(BPA Learn Time)"<< endl;
	BP_Learn::fWrite_Weight();
}

void BP_Learn::TestBP_V()
{
	double In_Put[2] = { 0 };
	
	cout << "\n\nTest �� �Է� �� ����\n\n";
	for (int i = 0; i < nInput_Number_Inputs; ++i)
	{
		cout << i + 1 << "��° �Է� �� :";
		cin >> In_Put[i];
	}
	inc = 0;
	int carry(0);
	// Output�� ����� Neurons Min Number
	int Lable(Number_Neurons - Hidden_Layer[Number_Layer - 1] - nInput_Number_Outputs);
	// Output�� ����� Neurons Max Number
	int New_Lable(Number_Neurons - nInput_Number_Outputs);

	/*Input - Hidden Layer[0] ���� Sum,Sigmoid,Delta */
	for (int i = 0; i < Hidden_Layer[0]; ++i)
	{
		for (int j = 0; j < nInput_Number_Inputs; ++j)
		{
			Sum[i] += (In_Put[j + bnc * nInput_Number_Inputs] * Weight_Input_Layer[inc]);
			++inc;
		}
		Sum[i] += (Bias * Bias_Weight[i]);
		Sigmoid[i] = (1.0 / (1.0 + exp(-Sum[i])));
	}
	inc = 0;

	/*Hidden Layer�� ������ Sum, Sigmoid*/
	for (int i = (Number_Layer - 1); i > 0; --i)
	{
		k += Hidden_Layer[i];
		for (int j = New_Lable - (Hidden_Layer[i] + Out_Jump); j < (New_Lable - Out_Jump); ++j)
		{
			for (int n = (New_Lable - (Hidden_Layer[i - 1] + k)); n < (New_Lable - k); ++n)
			{
				Sum[j] += (Sigmoid[n] * Weight_Layer[i - 1][inc]);
				++inc;
			}
			Sum[j] += (Bias * Bias_Weight[j]);
			Sigmoid[j] = (1.0 / (1.0 + exp(-Sum[j])));
		}
		inc = 0;
		Out_Jump += Hidden_Layer[i];
	}
	Out_Jump = 0;
	k = 0;

	/*	Output Layer�� ����� Hidden Layer�̿��Ͽ� Output Sum,Sigmoid	*/
	for (int i = 0; i < nInput_Number_Outputs; ++i)
	{
		for (int j = Lable; j < New_Lable; ++j)
		{
			Sum_Output[i] += (Sigmoid[j] * Weight_Output_Layer[inc]);
			++inc;
		}
		Sum_Output[i] += (Bias * Bias_Weight[New_Lable + i]);
		Sigmoid_Output[i] = (1.0 / (1.0 + exp(-Sum_Output[i])));
	}
	inc = 0;


	cout <<"Test ���: " <<Sigmoid_Output[0] << endl;
}


void BP_Learn::fWrite_Weight()
{
	ofstream W_Input, W_Layer_1, W_Output, N_Input, N_Output, N_Hidden_Neurons, N_Layer, N_Bias, N_Neurons, LNG;

	LNG.open("Learning_Gain.txt");
	LNG << L_N_G << endl;
	LNG.close();

	N_Neurons.open("Number_Neurons.txt");
	N_Neurons << Number_Neurons << endl;
	N_Neurons.close();

	N_Bias.open("Weight_Bias.txt");
	for (int i = 0; i < Number_Neurons; ++i)	N_Bias << Bias_Weight[i] << endl;
	N_Bias.close();

	N_Input.open("Number_Input.txt");
	N_Input << nInput_Number_Inputs << endl;
	N_Input.close();

	N_Output.open("Number_Output.txt");
	N_Output << nInput_Number_Outputs << endl;
	N_Output.close();

	N_Layer.open("Number_Layer.txt");
	N_Layer << Number_Layer << endl;
	N_Layer.close();

	N_Hidden_Neurons.open("Number_Hidden_Neurons.txt");
	for (int i = 0; i < Number_Layer; ++i)
	{
		N_Hidden_Neurons << Hidden_Layer[i] << endl;
	}
	N_Hidden_Neurons.close();

	W_Input.open("Weight_Input.txt");
	for (int i = 0; i < (nInput_Number_Inputs *Hidden_Layer[0]); ++i)
	{
		W_Input << Weight_Input_Layer[i] << endl;
	}
	W_Input.close();

	W_Output.open("Weight_Output.txt");
	for (int i = 0; i < (nInput_Number_Outputs*Hidden_Layer[Number_Layer - 1]); ++i)
	{
		W_Output << Weight_Output_Layer[i] << endl;
	}
	W_Output.close();

	char filename[100] = { 0 };
	for (int i = 0; i < (Number_Layer - 1); ++i)
	{
		sprintf_s(filename, "Weight_Layer_%d.txt", i + 1);
		ofstream W_Layer_1;
		W_Layer_1.open(filename);
		for (int j = 0; j < (Hidden_Layer[i] * Hidden_Layer[i + 1]); ++j)
		{
			W_Layer_1 << Weight_Layer[i][j] << endl;
		}
	}

	W_Layer_1.close();
}





